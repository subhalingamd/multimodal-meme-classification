# import pytesseract
import os
from preprocessing import preprocess_image, preprocess_txt
import pickle
import pandas as pd
try:
    from PIL import Image
except ImportError:
    import Image

root = "/content/drive/MyDrive/MTL782-Memes Classifier/dataminingmtl782/"
train_path = "train_images/train_images"

data = {"image": [], "filepath": [], "text": [], "label": []}

df = pd.read_csv(root+"train.csv")
for index, row in df.iterrows():
    img_, text_, label_ = row["image id"], row["text"], int(row["label_num"])
    print(img_,": ",text_)
    try:
        '''
        if dirname == './dataset/positive':
            data['label'].append(int(1))
        if dirname == './dataset/neutral':
            data['label'].append(int(2))
        if dirname == './dataset/negative':
            data['label'].append(int(0))
        '''
        data['label'].append(label_)

        data['image'].append(
            preprocess_image(
                os.path.join(root+train_path, img_)))

        data['filepath'].append(
            os.path.join(img_))

        data['text'].append(
            preprocess_txt(text_))

    except Exception as e:
        print(e)
        continue

    print('\r images: {} texts: {} labels : {}'.format(len(data['image']), len(data['text']), len(data['label'])), end='')


with open("data_train.pkl", "wb") as pickle_out:
    pickle.dump(data, pickle_out)
pickle_out.close()
