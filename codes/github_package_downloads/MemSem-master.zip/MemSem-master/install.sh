pip install praw
sudo apt install tesseract-ocr
pip install pytesseract
pip install transformers
pip install tensorflow==2.1.0-rc0
pip install pandas 
pip install numpy
pip install nltk