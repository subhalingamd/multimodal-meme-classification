googleimagesdownload --keywords "dark negative memes" --limit 2000
googleimagesdownload --keywords "positive memes" --limit 2000
googleimagesdownload --keywords "nonsense memes" --limit 2000